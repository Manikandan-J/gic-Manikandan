import { ComponentFixture, TestBed } from '@angular/core/testing';

import { LobDataComponent } from './lob-data.component';

describe('LobDataComponent', () => {
  let component: LobDataComponent;
  let fixture: ComponentFixture<LobDataComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ LobDataComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(LobDataComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
