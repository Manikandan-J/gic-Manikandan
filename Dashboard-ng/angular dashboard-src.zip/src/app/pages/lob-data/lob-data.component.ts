import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from 'src/app/service/data-service.service';
@Component({
  selector: 'app-lob-data',
  templateUrl: './lob-data.component.html',
  styleUrls: ['./lob-data.component.css']
})
export class LobDataComponent implements OnInit {

  constructor(private router: Router,private dataService: DataServiceService) { }
  role: string = '';
  show: boolean = true;
  ngOnInit(): void {
    this.dataService.currentRole.subscribe(role => this.role =role);
    
  }
  
  searchLob()
  {
    this.router.navigate(['/LOBinputs']);
  }
  logOff()
  {
    this.router.navigate(['/login']);
  }
  triggerMail()
  {
    this.router.navigate(['/mailedSuccess']);
  }
}
