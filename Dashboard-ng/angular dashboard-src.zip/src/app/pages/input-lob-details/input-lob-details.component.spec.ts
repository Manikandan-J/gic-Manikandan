import { ComponentFixture, TestBed } from '@angular/core/testing';

import { InputLobDetailsComponent } from './input-lob-details.component';

describe('InputLobDetailsComponent', () => {
  let component: InputLobDetailsComponent;
  let fixture: ComponentFixture<InputLobDetailsComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ InputLobDetailsComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(InputLobDetailsComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
