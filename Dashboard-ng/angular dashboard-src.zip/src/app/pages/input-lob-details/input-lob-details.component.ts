import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from 'src/app/service/data-service.service';

@Component({
  selector: 'app-input-lob-details',
  templateUrl: './input-lob-details.component.html',
  styleUrls: ['./input-lob-details.component.css']
})
export class InputLobDetailsComponent implements OnInit {

  constructor(private router: Router,private dataService: DataServiceService) { }
  role: string = '';
  show: boolean = true;
  ngOnInit(): void {
     this.dataService.currentRole.subscribe(role => this.role =role);
     this.toggleAgentView();
  }
  ShowLobDetails()
  {
    this.router.navigate(['/LOBData']);
  }
  toggleAgentView()
  {
      if(this.role=='agent')
      {
        this.show = false;
      }
  }
  logOff()
  {
    this.router.navigate(['/login']);
  }
}
