import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmailAcknowledgeComponent } from './common/email-acknowledge/email-acknowledge.component';
import { LoginComponent } from './common/login/login.component';
import { InputLobDetailsComponent } from './pages/input-lob-details/input-lob-details.component';
import { LobDataComponent } from './pages/lob-data/lob-data.component';

const routes: Routes = [
  { path: '', redirectTo: '/login', pathMatch: 'full' },
 
    
    {path:'login',component: LoginComponent},
    {path:'LOBinputs',component: InputLobDetailsComponent},
    {path:'LOBData',component: LobDataComponent},
    {path:'mailedSuccess',component:EmailAcknowledgeComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
