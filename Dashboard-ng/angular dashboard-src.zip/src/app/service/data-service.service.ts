import { Injectable } from '@angular/core';
import { BehaviorSubject } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
export class DataServiceService {
// data service for getting/seting role data
private role = new BehaviorSubject('null');
currentRole = this.role.asObservable();

setRole(role: string) {
  this.role.next(role);
}
  constructor() { }
}
