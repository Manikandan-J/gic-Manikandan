import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { DataServiceService } from 'src/app/service/data-service.service';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  email: string = '';
  password: string = ''; 
  invalidCredential: boolean =false;
  constructor(private router: Router,private dataService: DataServiceService) { }

  ngOnInit(): void {
  }
  onSubmit()
  {
     if(this.email == 'business@mail.com'&&this.password=='test@123')
     {
       
      this.dataService.setRole('admin');
      this.router.navigate(['/LOBinputs']);
      
     }
     else if(this.email == 'agent@mail.com'&&this.password=='test@123')
     {
       this.dataService.setRole('agent');
       this.router.navigate(['/LOBinputs']);

     }
     else{
      this.invalidCredential =true;
     }
    
  
  }

}
