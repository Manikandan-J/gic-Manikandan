import { ComponentFixture, TestBed } from '@angular/core/testing';

import { EmailAcknowledgeComponent } from './email-acknowledge.component';

describe('EmailAcknowledgeComponent', () => {
  let component: EmailAcknowledgeComponent;
  let fixture: ComponentFixture<EmailAcknowledgeComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ EmailAcknowledgeComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(EmailAcknowledgeComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
