import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-email-acknowledge',
  templateUrl: './email-acknowledge.component.html',
  styleUrls: ['./email-acknowledge.component.css']
})
export class EmailAcknowledgeComponent implements OnInit {

  constructor(private router: Router) { }

  ngOnInit(): void {
  }
  searchLob()
  {
    this.router.navigate(['/LOBinputs']);
  }
  logOff()
  {
    this.router.navigate(['/login']);
  }
 
}
