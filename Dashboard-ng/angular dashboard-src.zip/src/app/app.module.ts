import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { FormsModule } from '@angular/forms'; 
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { HeaderComponent } from './common/header/header.component';
import { LoginComponent } from './common/login/login.component';
import { FrameComponent } from './frame/frame.component';
import { InputLobDetailsComponent } from './pages/input-lob-details/input-lob-details.component';
import { LobDataComponent } from './pages/lob-data/lob-data.component';
import { EmailAcknowledgeComponent } from './common/email-acknowledge/email-acknowledge.component';

@NgModule({
  declarations: [
    AppComponent,
    HeaderComponent,
    LoginComponent,
    FrameComponent,
    InputLobDetailsComponent,
    LobDataComponent,
    EmailAcknowledgeComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule { }
